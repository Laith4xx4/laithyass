﻿delete from librarian where lid=1
delete from librarian where lid=2
delete from librarian where lid=3