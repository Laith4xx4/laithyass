import React from "react";
import { useAuth } from "@/lib/use-auth";
import Navbar from "@/components/Navbar";

const AdminDashboard = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="mt-4">Welcome, {user?.firstName}!</p>
        <div className="mt-8">
          <h2 className="text-lg font-semibold mb-2">إحصائيات النظام</h2>
          <ul>
            <li>عدد المستخدمين: 100</li>
            <li>عدد العقارات: 50</li>
            <li>عدد الحجوزات: 20</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard; 